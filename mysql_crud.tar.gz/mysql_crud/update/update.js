var con = require("../db_connection");

var connection = con.getConnection();

connection.connect();

var express = require("express");

var router = express.Router();

router.post("/",(req,res)=>{
    var ID = req.body.ID;
    var Name = req.body.Name;
    var Age = req.body.Age;
    var Department = req.body.Department;
    var Subject = req.body.Subject;

    connection.query("update Student set Name='"+Name+"' where ID="+ID+" ",
                    (err,result)=>{
  
       if(err){
            res.send({"update":"fail"});
        }else{
            res.send({"update":"success"});
        }
    });
});

module.exports = router;


