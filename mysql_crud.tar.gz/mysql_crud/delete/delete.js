var con = require("../db_connection");

var connection = con.getConnection();

connection.connect();

var express = require("express");

var router = express.Router();

router.post("/",(req,res)=>{
    var ID= req.body.ID;
    connection.query("delete from Student where ID="+ID+" ",
                        (err,result)=>{
        if(err){
            res.send({"delete":"fail"});
        }else{
            res.send({"delete":"success"});
        }
    });
});

module.exports = router; 
