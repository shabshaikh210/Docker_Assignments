var express = require('express');
var bodyParser = require('body-parser');
var cors = require('cors');



var app = express();


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));

//enable the cors
app.use(cors());


//import the fetch module

var fetch = require('./fetch/fetch');
app.use('/fetch',fetch);


//import the insert module

var insert = require('./insert/insert');
app.use('/insert',insert);


//import the update module

var update = require('./update/update');
app.use('/update',update);


//import delete module
var remove = require('./delete/delete');
app.use('/delete',remove);

//assign the port number
app.listen(8080);

console.log('Server Listening on Port Number 8080');
